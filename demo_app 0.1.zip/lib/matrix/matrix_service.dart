import 'package:matrix/matrix.dart';

class MatrixService {
  final String homeserver = 'http://tg.agatzub.ru:8008';

  late final Client client;

  MatrixService() {
    client = Client(
      'demo_app', // любое имя
      databaseBuilder: (_) => Database.memory(), // пока без локального кеша
    );
  }

  Future<void> init() async {
    await client.checkHomeserver(Uri.parse(homeserver));
  }

  Future<void> loginWithPassword({
    required String mxid,
    required String password,
  }) async {
    await client.login(
      LoginType.mLoginPassword,
      identifier: AuthenticationUserIdentifier(user: mxid),
      password: password,
      initialDeviceDisplayName: 'Flutter demo_app',
    );
  }

  /// Список комнат (диалогов)
  List<Room> get rooms {
    final list = client.rooms;
    // Можно отсортировать как угодно
    list.sort((a, b) => (b.lastEvent?.originServerTs ?? 0)
        .compareTo(a.lastEvent?.originServerTs ?? 0));
    return list;
  }

  /// Подписка на синк (чтобы приходили новые события)
  Future<void> startSync() async {
    await client.sync();
  }

  Future<void> logout() async {
    await client.logout();
  }
}
