import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers/stores_providers.dart';

import '../../shared/db_service.dart';
import '../../shared/conversation_store.dart';
import '../../shared/conversation_models.dart';
import '../../shared/message_source.dart';
import '../../shared/contact_store.dart';
import '../../shared/contact_models.dart';
import '../contact/contact_page.dart';


const bool kEnableAutoReply = true; // DEBUG: easy to turn off later

class ChatPage extends ConsumerStatefulWidget {
  final String? conversationId;
  final String contactId;
  final MessageSource channelSource;
  final String channelHandle;

  const ChatPage({
    super.key,
    this.conversationId,
    required this.contactId,
    required this.channelSource,
    required this.channelHandle,
  });

  @override
  ConsumerState<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends ConsumerState<ChatPage> {
  bool _selectionMode = false;
  final Set<String> _selectedIds = <String>{};

  String _genId(int nowMs) => '${nowMs}_${_rng.nextInt(1<<32)}';

  final _rng = Random();

  final TextEditingController _controller = TextEditingController();
  final ScrollController _scroll = ScrollController();

  // Autoscroll behavior (WhatsApp-like):
  // - If user is at bottom -> autoscroll on new messages
  // - If user scrolled up -> keep position, show a "new messages" button
  static const double _bottomThresholdPx = 56; // how close to bottom counts as "at bottom"
  bool _isAtBottom = true;
  int _pendingNewMessages = 0;

  Color get _appBarColor => widget.channelSource.color;

  final GlobalKey _listKey = GlobalKey();
  final Map<String, GlobalKey> _dayHeaderKeys = {};
  String? _stickyDayLabel;
  bool _stickyVisible = false;

  final List<_UiMessage> _messages = [];
  String? _effectiveConversationId;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _bootstrap();
    _scroll.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scroll.removeListener(_onScroll);
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _onScroll() {
    final listCtx = _listKey.currentContext;
    if (listCtx == null) return;
    final listObj = listCtx.findRenderObject();
    if (listObj is! RenderBox) return;

    String? bestAbove;
    double bestAboveDy = -1e9;
    String? bestBelow;
    double bestBelowDy = 1e9;

    for (final entry in _dayHeaderKeys.entries) {
      final ctx = entry.value.currentContext;
      if (ctx == null) continue;
      final obj = ctx.findRenderObject();
      if (obj is! RenderBox || !obj.attached) continue;

      final dy = obj.localToGlobal(Offset.zero, ancestor: listObj).dy;

      if (dy <= 0 && dy > bestAboveDy) {
        bestAboveDy = dy;
        bestAbove = entry.key;
      } else if (dy > 0 && dy < bestBelowDy) {
        bestBelowDy = dy;
        bestBelow = entry.key;
      }
    }

    final current = bestAbove ?? bestBelow;
    final shouldShow = _scroll.hasClients && _scroll.offset > 0 && current != null;

    // Track whether the user is at (or very near) the bottom.
    if (_scroll.hasClients) {
      final max = _scroll.position.maxScrollExtent;
      final atBottomNow = (max - _scroll.offset) <= _bottomThresholdPx;
      if (atBottomNow != _isAtBottom) {
        setState(() {
          _isAtBottom = atBottomNow;
          if (_isAtBottom) {
            _pendingNewMessages = 0;
          }
        });
      } else if (_isAtBottom && _pendingNewMessages != 0) {
        // Safety: if user is at bottom, there shouldn't be pending messages.
        setState(() => _pendingNewMessages = 0);
      }
    }

    if (_stickyDayLabel != current || _stickyVisible != shouldShow) {
      setState(() {
        _stickyDayLabel = current;
        _stickyVisible = shouldShow;
      });
    }
  }

  Future<void> _bootstrap() async {
    await DbService.instance.init();

    final convId = widget.conversationId;
    if (convId != null) {
      _effectiveConversationId = convId;
    } else {
      final conv = ConversationStore.instance.ensureConversation(
        source: widget.channelSource,
        handle: widget.channelHandle,
        contactId: widget.contactId,
      );
      _effectiveConversationId = conv.id;
    }

    // При заходе в чат считаем диалог прочитанным
    final cid = _effectiveConversationId;
    if (cid != null) {
      ConversationStore.instance.markAsRead(cid);
    }

    final id = _effectiveConversationId;
    if (id != null) {
      final stored = await DbService.instance.loadMessages(
        contactId: widget.contactId,
        conversationId: id,
      );
      if (!mounted) return;
      setState(() {
        _messages
          ..clear()
          ..addAll(
            stored.map(
              (m) => _UiMessage(
                id: m.id,
                text: m.text,
                isOutgoing: m.isOutgoing,
                createdAtMs: m.createdAtMs,
                reaction: m.myReaction,
                editedAtMs: m.editedAtMs,
              ),
            ),
          );
        _loading = false;
        _isAtBottom = true;
        _pendingNewMessages = 0;
      });
      _scrollToBottom();
    } else {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 140),
        curve: Curves.easeOut,
      );
    });
  }

  void _maybeAutoScroll({required bool force}) {
    // force: used for отправка сообщения пользователем (ожидаемо прыгнуть вниз)
    if (force || _isAtBottom) {
      _pendingNewMessages = 0;
      _scrollToBottom();
      return;
    }
    if (mounted) {
      setState(() {
        _pendingNewMessages += 1;
      });
    }
  }

  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    final convId = _effectiveConversationId ?? widget.conversationId;
    if (convId == null) return;

    final ts = DateTime.now().millisecondsSinceEpoch;

    // 1) UI
    if (mounted) {
      setState(() {
        _messages.add(_UiMessage(id: "msg_${convId}_$ts", text: text, isOutgoing: true, createdAtMs: ts));
      });
    }
    _controller.clear();
    _maybeAutoScroll(force: true);

    // 2) DB
    await DbService.instance.addMessage(
      contactId: widget.contactId,
      conversationId: convId,
      isOutgoing: true,
      text: text,
      createdAtMs: ts,
    );

    
    _scheduleAutoReply(original: text);
    // 3) Обновим диалог (lastMessage/updatedAt) и поднимем его наверх в списке
    ConversationStore.instance.touchConversation(
      convId,
      lastMessage: text,
      updatedAt: DateTime.fromMillisecondsSinceEpoch(ts),
      unreadCount: 0,
    );
  }

  Future<void> _scheduleAutoReply({required String original}) async {
    if (!kEnableAutoReply) return;

    await Future<void>.delayed(Duration(milliseconds: 650 + _rng.nextInt(900)));
    if (!mounted) return;

    final conversationId = _effectiveConversationId ?? widget.conversationId;

    final replies = <String>[
      'Хорошо 🙂',
      'Ок, понял.',
      'Супер, спасибо!',
      'Сейчас уточню и напишу.',
      'Принял 👌',
    ];
    final text = replies[_rng.nextInt(replies.length)];

    final nowMs = DateTime.now().millisecondsSinceEpoch;
    setState(() {
      _messages.add(_UiMessage(id: _genId(nowMs), text: text, isOutgoing: false, createdAtMs: nowMs));
    });

    _maybeAutoScroll(force: false);

    if (conversationId == null) return;

    await DbService.instance.addMessage(
      conversationId: conversationId,
      contactId: widget.contactId,
      text: text,
      isOutgoing: false,
      createdAtMs: nowMs,
    );

    // Обновим превью в списке и поднимем диалог наверх.
    // Пока чат открыт, входящее НЕ должно становиться "непрочитанным".
    ConversationStore.instance.touchConversation(
      conversationId,
      lastMessage: text,
      updatedAt: DateTime.fromMillisecondsSinceEpoch(nowMs),
      unreadCount: 0,
    );
  }
  @override
  
  String _fmtTime(int ms) {
    final dt = DateTime.fromMillisecondsSinceEpoch(ms);
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

Widget build(BuildContext context) {
    return Scaffold(
      appBar: _selectionMode
          ? AppBar(
              backgroundColor: widget.channelSource.color,

              leading: IconButton(
                icon: const Icon(Icons.close),
                onPressed: _exitSelectionMode,
              ),
              title: Text(_selectedIds.length.toString()),
              actions: [
                IconButton(
                  icon: const Icon(Icons.copy),
                  onPressed: _selectedIds.isEmpty ? null : _selectionActionCopy,
                ),
                IconButton(
                  icon: const Icon(Icons.forward),
                  onPressed: () {
                    _exitSelectionMode();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Скоро 🙂')),
                    );
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: _selectedIds.isEmpty ? null : _selectionActionDelete,
                ),
              ],
            )
          : AppBar(
              backgroundColor: widget.channelSource.color,

              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => Navigator.pop(context),
              ),
              titleSpacing: 0,
              title: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => ContactPage(contactId: widget.contactId),
                  ),
                );
              },
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: Colors.white.withOpacity(0.22),
                    child: Icon(
                      widget.channelSource.icon,
                      size: 18,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Builder(
                      builder: (context) {
                        // Rebuild when contacts store updates.
                        ref.watch(contactsVersionProvider);
                        final store = ref.read(contactStoreProvider);
                        final contact = store.tryGet(widget.contactId);

                        final title = (contact?.preferredTitle.trim().isNotEmpty ?? false)
                            ? contact!.preferredTitle.trim()
                            : widget.channelHandle;

                        final subtitle = '${widget.channelSource.label} · ${widget.channelHandle}';

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                            Text(
                              subtitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Colors.white.withOpacity(0.85),
                                  ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
              actions: const [
                Icon(Icons.videocam_outlined),
                SizedBox(width: 10),
                Icon(Icons.call_outlined),
                SizedBox(width: 10),
                Icon(Icons.more_vert),
                SizedBox(width: 6),
              ],
            ),
        body: Column(
        children: [
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : Stack(
                  children: [
                    Positioned.fill(
                      child: Image.asset('assets/chat_bg.png', fit: BoxFit.cover),
                    ),
                    ListView.builder(
                      key: _listKey,
                      controller: _scroll,
                      padding: const EdgeInsets.all(12),
                    itemCount: _messages.length,
                    itemBuilder: (context, index) {
                      final m = _messages[index];
                      final bool showDayHeader;
                      if (index == 0) {
                        showDayHeader = true;
                      } else {
                        final prev = _messages[index - 1];
                        showDayHeader = !_isSameDay(m.createdAtMs, prev.createdAtMs);
                      }


                      final headerText = _formatDayHeader(m.createdAtMs);
                      return Column(
                        children: [
                          if (showDayHeader)
                          _DayHeader(
                            key: _dayHeaderKeys.putIfAbsent(headerText, () => GlobalKey()),
                            text: headerText,
                          ),
                          _MessageBubble(
                            message: m,
                            selected: _selectedIds.contains(m.id),
                            onTap: () => _onMessageTap(m),
                            onLongPress: () => _onMessageLongPress(m),
                          ),
                        ],
                      );
                    },
                    ),                    IgnorePointer(
                      child: AnimatedOpacity(
                        opacity: (_stickyVisible && _stickyDayLabel != null) ? 1.0 : 0.0,
                        duration: const Duration(milliseconds: 120),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.06),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: Text(
                                _stickyDayLabel ?? '',
                                style: Theme.of(context).textTheme.labelMedium,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                    // "New messages jump-to-bottom button (only when user is not at bottom)
                    if (!_isAtBottom && _pendingNewMessages > 0)
                      Positioned(
                        right: 14,
                        bottom: 14,
                        child: SafeArea(
                          minimum: const EdgeInsets.only(bottom: 56),
                          child: Material(
                            elevation: 2,
                            borderRadius: BorderRadius.circular(999),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(999),
                              onTap: () {
                                if (mounted) {
                                  setState(() {
                                    _pendingNewMessages = 0;
                                  });
                                }
                                _scrollToBottom();
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(Icons.arrow_downward, size: 18),
                                    if (_pendingNewMessages > 1) ...[
                                      const SizedBox(width: 6),
                                      Text(
                                        _pendingNewMessages.toString(),
                                        style: Theme.of(context).textTheme.labelLarge,
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
          ),
          _buildInput(),
        ],
      ),
    );
  }

  Widget _buildInput() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
        child: Shortcuts(
          shortcuts: {
            LogicalKeySet(LogicalKeyboardKey.control, LogicalKeyboardKey.enter): _SendIntent(),
            LogicalKeySet(LogicalKeyboardKey.meta, LogicalKeyboardKey.enter): _SendIntent(),
          },
          child: Actions(
            actions: {
              _SendIntent: CallbackAction<_SendIntent>(
                onInvoke: (_) {
                  _sendMessage();
                  return null;
                },
              ),
            },
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    minLines: 1,
                    maxLines: 5,
                    decoration: const InputDecoration(
                      hintText: 'Сообщение',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }



    void _exitSelectionMode() {
    if (!_selectionMode) return;
    setState(() {
      _selectionMode = false;
      _selectedIds.clear();
    });
  }

  void _toggleSelected(String id) {
    setState(() {
      if (_selectedIds.contains(id)) {
        _selectedIds.remove(id);
      } else {
        _selectedIds.add(id);
      }
      if (_selectedIds.isEmpty) {
        _selectionMode = false;
      }
    });
  }

  Future<void> _onMessageTap(_UiMessage m) async {
    if (_selectionMode) {
      _toggleSelected(m.id);
      return;
    }
    await _showMessageMenu(m);
  }

  Future<void> _onMessageLongPress(_UiMessage m) async {
    if (!_selectionMode) {
      setState(() {
        _selectionMode = true;
        _selectedIds.clear();
        _selectedIds.add(m.id);
      });
      return;
    }
    _toggleSelected(m.id);
  }

  Future<void> _showMessageMenu(_UiMessage m) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        Widget reactionButton(String emoji) {
          return InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => Navigator.pop(ctx, 'react:$emoji'),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: Text(emoji, style: const TextStyle(fontSize: 22)),
            ),
          );
        }

        final canEdit = m.isOutgoing;
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(ctx).size.height * 0.75,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    reactionButton('❤️'),
                    reactionButton('😍'),
                    reactionButton('😁'),
                    reactionButton('🎉'),
                    reactionButton('👍'),
                    reactionButton('👎'),
                    reactionButton('🔥'),
                  ],
                ),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.reply),
                title: const Text('Ответить'),
                onTap: () => Navigator.pop(ctx, 'reply'),
              ),
              ListTile(
                leading: const Icon(Icons.copy),
                title: const Text('Копировать'),
                onTap: () => Navigator.pop(ctx, 'copy'),
              ),
              ListTile(
                leading: const Icon(Icons.forward),
                title: const Text('Переслать'),
                onTap: () => Navigator.pop(ctx, 'forward'),
              ),
              ListTile(
                leading: const Icon(Icons.push_pin_outlined),
                title: const Text('Закрепить'),
                onTap: () => Navigator.pop(ctx, 'pin'),
              ),
ListTile(
                leading: const Icon(Icons.note_add_outlined),
                title: const Text('Добавить в заметки контакта'),
                onTap: () => Navigator.pop(ctx, 'note'),
              ),
              if (canEdit)
              ListTile(
                leading: const Icon(Icons.edit_outlined),
                title: const Text('Изменить'),
                onTap: () => Navigator.pop(ctx, 'edit'),
              ),
              ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('Удалить'),
                onTap: () => Navigator.pop(ctx, 'delete'),
              ),
              const SizedBox(height: 8),
            
                ],
              ),
            ),
          ),
        );
},
    );

    if (!mounted || action == null) return;

    if (action.startsWith('react:')) {
      final emoji = action.substring('react:'.length);
      final next = (m.reaction == emoji) ? null : emoji;
      setState(() => m.reaction = next);
      // Persist reaction so it survives restart.
      // Android will render emoji using Noto Color Emoji by default.
      // (If reaction is null, we clear it in DB.)
      DbService.instance.setMessageReaction(messageId: m.id, reaction: next);
      return;
    }

    switch (action) {
      case 'copy':
        Clipboard.setData(ClipboardData(text: m.text));
        break;
      case 'note':
        await _addMessageToContactNotes(m.text);
        break;
      case 'delete':
        await _deleteMessageById(m.id);
        break;
      case 'edit':
        await _editMessage(m);
        break;
      case 'reply':
      case 'forward':
      case 'pin':
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Скоро 🙂')),
          );
        }
        break;
    }
  }

  Future<void> _addMessageToContactNotes(String text) async {
    final store = ref.read(contactStoreProvider);
    await store.addNote(widget.contactId, text);
  }

  

Future<void> _editMessage(_UiMessage m) async {
  if (!m.isOutgoing) return;

  final controller = TextEditingController(text: m.text);
  final newText = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Изменить сообщение'),
      content: TextField(
        controller: controller,
        autofocus: true,
        maxLines: null,
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, controller.text.trim()),
          child: const Text('Сохранить'),
        ),
      ],
    ),
  );

  if (newText == null) return;
  if (newText.isEmpty || newText == m.text) return;

  final ts = DateTime.now().millisecondsSinceEpoch;

  setState(() {
    m.text = newText;
    m.editedAtMs = ts;
  });

  await DbService.instance.editMessage(messageId: m.id, newText: newText, editedAtMs: ts);
}

Future<void> _deleteMessageById(String id) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить сообщение?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Удалить')),
        ],
      ),
    );
    if (ok != true) return;

    setState(() {
      _messages.removeWhere((e) => e.id == id);
    });
    await DbService.instance.deleteMessage(messageId: id);
  }

  Future<void> _selectionActionCopy() async {
    final selected = _messages.where((m) => _selectedIds.contains(m.id)).toList();
    selected.sort((a, b) => a.createdAtMs.compareTo(b.createdAtMs));
    final combined = selected.map((m) => m.text).join('\n');
    Clipboard.setData(ClipboardData(text: combined));
    _exitSelectionMode();
  }

  Future<void> _selectionActionDelete() async {
    final ids = _selectedIds.toList();
    for (final id in ids) {
      await _deleteMessageById(id);
    }
    _exitSelectionMode();
  }


  bool _isSameDay(int aMs, int bMs) {
    final a = DateTime.fromMillisecondsSinceEpoch(aMs);
    final b = DateTime.fromMillisecondsSinceEpoch(bMs);
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  String _formatDayHeader(int ms) {
    final dt = DateTime.fromMillisecondsSinceEpoch(ms);
    final now = DateTime.now();
    final yesterday = now.subtract(const Duration(days: 1));

    String dow(DateTime d) {
      switch (d.weekday) {
        case DateTime.monday:
          return 'Пн';
        case DateTime.tuesday:
          return 'Вт';
        case DateTime.wednesday:
          return 'Ср';
        case DateTime.thursday:
          return 'Чт';
        case DateTime.friday:
          return 'Пт';
        case DateTime.saturday:
          return 'Сб';
        case DateTime.sunday:
          return 'Вс';
      }
      return '';
    }

    String datePart(DateTime d) {
      final dd = d.day.toString().padLeft(2, '0');
      final mm = d.month.toString().padLeft(2, '0');
      final base = '$dd.$mm';
      if (d.year != now.year) return '$base.${d.year}';
      return base;
    }

    if (_isSameDay(ms, now.millisecondsSinceEpoch)) {
      return 'Сегодня (${datePart(dt)}, ${dow(dt)})';
    }
    if (_isSameDay(ms, yesterday.millisecondsSinceEpoch)) {
      return 'Вчера (${datePart(dt)}, ${dow(dt)})';
    }
    return '${datePart(dt)}, ${dow(dt)}';
  }
}

class _SendIntent extends Intent {
  const _SendIntent();
}

class _DayHeader extends StatelessWidget {
  final String text;
  const _DayHeader({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceVariant,
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            text,
            style: Theme.of(context).textTheme.labelMedium,
          ),
        ),
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  static String _formatTime(int ms) {
    final dt = DateTime.fromMillisecondsSinceEpoch(ms);
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  final _UiMessage message;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final bool selected;

  const _MessageBubble({
    required this.message,
    this.onTap,
    this.onLongPress,
    this.selected = false,
  });

  @override
  Widget build(BuildContext context) {
    final isOut = message.isOutgoing;
    final align = isOut ? Alignment.centerRight : Alignment.centerLeft;

    final bubbleColor = isOut ? Colors.blue : Colors.grey.shade300;
    final textColor = isOut ? Colors.white : Colors.black87;

    final border = selected
        ? Border.all(color: Theme.of(context).colorScheme.primary, width: 2)
        : null;

    final bubble = Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: bubbleColor,
        border: border,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(14),
          topRight: const Radius.circular(14),
          bottomLeft: Radius.circular(isOut ? 14 : 4),
          bottomRight: Radius.circular(isOut ? 4 : 14),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              message.text,
              style: TextStyle(color: textColor, height: 1.25),
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (message.editedAtMs != null)
                Text(
                  'Изм.',
                  style: TextStyle(fontSize: 11, color: textColor.withOpacity(0.75)),
                ),
              if (message.editedAtMs != null) const SizedBox(width: 6),
              Text(
                _formatTime(message.createdAtMs),
                style: TextStyle(fontSize: 11, color: textColor.withOpacity(0.75)),
              ),
            ],
          ),
        ],
      ),
    );

    return Align(
      alignment: align,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.78,
        ),
        child: GestureDetector(
          onTap: onTap,
          onLongPress: onLongPress,
          child: Column(
            crossAxisAlignment: isOut ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: [
              bubble,
              if (message.reaction != null)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(message.reaction!, style: const TextStyle(fontSize: 14)),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _UiMessage {
  final String id;
  String text;
  final bool isOutgoing;
  final int createdAtMs;
  int? editedAtMs;
  String? reaction;

  _UiMessage({
    required this.id,
    required this.text,
    required this.isOutgoing,
    required this.createdAtMs,
    this.editedAtMs,
    this.reaction,
  });
}
