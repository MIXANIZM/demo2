import 'dart:async';

import 'package:flutter/foundation.dart';

import 'conversation_models.dart';
import 'contact_models.dart';
import 'contact_store.dart';
import 'db_service.dart';
import 'message_source.dart';
import 'phone_utils.dart';

/// Максимально простой in-memory store для диалогов.
///
/// Ключевое правило проекта:
/// ❗ любой новый входящий диалог всегда проходит через ContactStore.getOrCreateForIncoming.
class ConversationStore {
  ConversationStore._();

  static final ConversationStore instance = ConversationStore._();

  final List<Conversation> _conversations = <Conversation>[];

  /// Простейший способ уведомлять UI без провайдеров.
  final ValueNotifier<int> version = ValueNotifier<int>(0);

  List<Conversation> get all => List<Conversation>.unmodifiable(_conversations);

  /// Заменить весь список (используется для гидрации из БД).
  void replaceAll(List<Conversation> items) {
    _conversations
      ..clear()
      ..addAll(items);
    _conversations.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    version.value++;
  }

  Conversation? tryGet(String id) {
    for (final c in _conversations) {
      if (c.id == id) return c;
    }
    return null;
  }

  /// Добавить/обновить входящее сообщение.
  ///
  /// - создаёт контакт (или находит существующий) через getOrCreateForIncoming
  /// - создаёт диалог (или находит существующий) по (source+handle)
  /// - обновляет lastMessage/updatedAt
  Conversation addIncomingMessage({
    required MessageSource source,
    required String handle,
    required String messageText,
    String? displayName,
  }) {
    final normalizedHandle = PhoneUtils.normalizeForHandle(handle);
    final contact = ContactStore.instance.getOrCreateForIncoming(
      source: source,
      handle: normalizedHandle,
      displayName: displayName,
    );

    final normalized = normalizedHandle;
    final existing = _conversations.cast<Conversation?>().firstWhere(
          (c) => c != null && c.source == source && c.handle.toLowerCase() == normalized.toLowerCase(),
          orElse: () => null,
        );

    if (existing != null) {
      // Если раньше было приклеено к другому контакту — обновим ссылку.
      if (existing.contactId != contact.id) {
        existing.contactId = contact.id;
      }
      existing.lastMessage = messageText;
      existing.updatedAt = DateTime.now();
      version.value++;
      unawaited(DbService.instance.upsertConversation(existing));
      return existing;
    }

    final conv = Conversation(
      id: _newId(),
      contactId: contact.id,
      source: source,
      handle: normalized,
      lastMessage: messageText,
      updatedAt: DateTime.now(),
    );

    _conversations.insert(0, conv);
    version.value++;
    unawaited(DbService.instance.upsertConversation(conv));
    return conv;
  }

  /// Ensure a conversation exists for a given channel.
  /// Useful when we create a contact manually from search, before real sources are connected.
  Conversation ensureConversation({
    required MessageSource source,
    required String handle,
    required String contactId,
    String lastMessage = 'Контакт создан',
  }) {
    final normalized = PhoneUtils.normalizeForHandle(handle);
    final existing = _conversations.cast<Conversation?>().firstWhere(
          (c) => c != null && c.source == source && c.handle.toLowerCase() == normalized.toLowerCase(),
          orElse: () => null,
        );

    if (existing != null) {
      if (existing.contactId != contactId) {
        existing.contactId = contactId;
      }
      existing.lastMessage = lastMessage;
      existing.updatedAt = DateTime.now();
      version.value++;
      unawaited(DbService.instance.upsertConversation(existing));
      return existing;
    }

    final conv = Conversation(
      id: _newId(),
      contactId: contactId,
      source: source,
      handle: normalized,
      lastMessage: lastMessage,
      updatedAt: DateTime.now(),
    );
    _conversations.insert(0, conv);
    version.value++;
    unawaited(DbService.instance.upsertConversation(conv));
    return conv;
  }

  /// Вручную привязать диалог к выбранному контакту.
  ///
  /// По умолчанию добавляет канал в контакт (source+handle).
  void linkConversationToContact(
    String conversationId,
    String contactId, {
    bool alsoUpsertChannel = true,
  }) {
    final conv = tryGet(conversationId);
    if (conv == null) return;

    if (alsoUpsertChannel) {
      ContactStore.instance.upsertChannel(
        contactId,
        source: conv.source,
        handle: conv.handle,
        makePrimary: false,
      );
    }

    conv.contactId = contactId;
    version.value++;
    unawaited(DbService.instance.upsertConversation(conv));
  }

  /// Создать новый контакт и привязать к нему диалог.
  Contact createNewContactAndLink(String conversationId) {
    final conv = tryGet(conversationId);
    if (conv == null) {
      throw StateError('Conversation not found: $conversationId');
    }

    final c = ContactStore.instance.getOrCreateForIncoming(
      source: conv.source,
      handle: conv.handle,
      displayName: conv.handle,
    );

    conv.contactId = c.id;
    version.value++;
    unawaited(DbService.instance.upsertConversation(conv));
    return c;
  }

  /// Демо-сид (чтобы UI не был пустым).
  void ensureDemoSeed() {
    if (_conversations.isNotEmpty) return;

    addIncomingMessage(
      source: MessageSource.telegram,
      handle: '+7 911 860-24-88',
      messageText: 'Вот тут есть 2 видео как им пользоваться',
      displayName: '+7 911 860-24-88',
    );

    // тот же номер, но WhatsApp — контакт будет общий (склейка по телефону)
    addIncomingMessage(
      source: MessageSource.whatsapp,
      handle: '+7 911 860-24-88',
      messageText: 'Ок, понял, спасибо!',
      displayName: '+7 911 860-24-88',
    );

    addIncomingMessage(
      source: MessageSource.whatsapp,
      handle: '+7 953 324-94-35',
      messageText: 'Да, конечно. Но только пуансонов у нас сейчас мало…',
      displayName: 'Светлана',
    );

    addIncomingMessage(
      source: MessageSource.whatsapp,
      handle: '@elena_shop',
      messageText: 'И мы вас ❤️',
      displayName: 'Elena',
    );

    addIncomingMessage(
      source: MessageSource.instagram,
      handle: '@anastasia',
      messageText: '😋😋😋',
      displayName: 'Анастасия',
    );
  }

  String _newId() => DateTime.now().microsecondsSinceEpoch.toString();
}
