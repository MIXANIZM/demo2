import 'dart:async';

import 'package:drift/drift.dart';

import 'app_db.dart' as db;
import 'contact_models.dart' as models;
import 'conversation_models.dart';
import 'message_source.dart';

/// Единая точка работы с локальной БД (Drift/SQLite).
///
/// Принцип: никаких Riverpod/Bloc. Просто singleton + fire-and-forget.
class DbService {
  DbService._();

  static final DbService instance = DbService._();

  db.AppDb? _db;

  db.AppDb get database {
    final d = _db;
    if (d == null) {
      throw StateError('DbService not initialized');
    }
    return d;
  }

  Future<void> init() async {
    // Создаем БД лениво.
    _db ??= db.AppDb();
  }

  Future<void> dispose() async {
    await _db?.close();
    _db = null;
  }

  /// Загрузить контакты из БД.
  Future<List<models.Contact>> loadContacts() async {
    final d = database;
    final contactRows = await d.select(d.contacts).get();
    if (contactRows.isEmpty) return const [];

    final channels = await d.select(d.contactChannels).get();
    final labels = await d.select(d.contactLabels).get();
    final notes = await d.select(d.contactNotes).get();

    final byId = <String, models.Contact>{};
    for (final r in contactRows) {
      byId[r.id] = models.Contact(
        id: r.id,
        displayName: r.displayName,
        // В БД эти поля могут быть null, а в наших моделях они не-null.
        // Держим пустую строку вместо null.
        firstName: r.firstName ?? '',
        lastName: r.lastName ?? '',
        company: r.company ?? '',
        channels: <models.ContactChannel>[],
        labels: <String>{},
        notes: <models.ContactNote>[],
      );
    }

    for (final ch in channels) {
      final c = byId[ch.contactId];
      if (c == null) continue;
      final src = MessageSourceExt.tryParse(ch.source);
      if (src == null) continue;
      c.channels.add(models.ContactChannel(source: src, handle: ch.handle, isPrimary: ch.isPrimary));
    }

    for (final lb in labels) {
      final c = byId[lb.contactId];
      if (c == null) continue;
      if (!c.labels.contains(lb.labelName)) c.labels.add(lb.labelName);
    }

    for (final n in notes) {
      final c = byId[n.contactId];
      if (c == null) continue;
      c.notes.add(models.ContactNote(id: n.id, createdAt: DateTime.fromMillisecondsSinceEpoch(n.createdAtMs), text: n.body));
    }

    for (final c in byId.values) {
      c.notes.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    }

    return byId.values.toList();
  }

  Future<List<Conversation>> loadConversations() async {
    final d = database;
    final convRows = await d.select(d.conversationsTable).get();
    if (convRows.isEmpty) return const [];
    return convRows
        .map(
          (r) => Conversation(
            id: r.id,
            contactId: r.contactId,
            source: MessageSourceExt.parse(r.source),
            handle: r.handle,
            lastMessage: r.lastMessage,
            updatedAt: DateTime.fromMillisecondsSinceEpoch(r.updatedAtMs),
          ),
        )
        .toList();
  }

  // -------------------- writes --------------------

  Future<void> upsertContact(models.Contact c) async {
    final d = database;
    await d.into(d.contacts).insertOnConflictUpdate(
          db.ContactsCompanion.insert(
            id: c.id,
            displayName: c.displayName,
            firstName: Value(c.firstName),
            lastName: Value(c.lastName),
            company: Value(c.company),
          ),
        );

    // Переписываем дочерние таблицы целиком для контакта (просто и надежно).
    await (d.delete(d.contactChannels)..where((t) => t.contactId.equals(c.id))).go();
    for (final ch in c.channels) {
      await d.into(d.contactChannels).insert(
            db.ContactChannelsCompanion.insert(
              contactId: c.id,
              source: ch.source.name,
              handle: ch.handle,
              isPrimary: Value(ch.isPrimary),
            ),
          );
    }

    await (d.delete(d.contactLabels)..where((t) => t.contactId.equals(c.id))).go();
    for (final label in c.labels) {
      await d.into(d.contactLabels).insert(
            db.ContactLabelsCompanion.insert(contactId: c.id, labelName: label),
          );
    }

    await (d.delete(d.contactNotes)..where((t) => t.contactId.equals(c.id))).go();
    for (final n in c.notes) {
      await d.into(d.contactNotes).insert(
            db.ContactNotesCompanion.insert(
              id: n.id,
              contactId: c.id,
              createdAtMs: n.createdAt.millisecondsSinceEpoch,
              body: n.text,
            ),
          );
    }
  }

  Future<void> upsertConversation(Conversation c) async {
    final d = database;
    await d.into(d.conversationsTable).insertOnConflictUpdate(
          db.ConversationsTableCompanion.insert(
            id: c.id,
            contactId: c.contactId,
            source: c.source.name,
            handle: c.handle,
            lastMessage: c.lastMessage,
            updatedAtMs: c.updatedAt.millisecondsSinceEpoch,
          ),
        );
  }
}

extension MessageSourceExt on MessageSource {
  static MessageSource parse(String name) {
    return MessageSource.values.firstWhere((e) => e.name == name, orElse: () => MessageSource.whatsapp);
  }

  static MessageSource? tryParse(String name) {
    for (final v in MessageSource.values) {
      if (v.name == name) return v;
    }
    return null;
  }
}
