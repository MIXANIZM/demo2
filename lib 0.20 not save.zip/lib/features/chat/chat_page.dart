import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../contact/contact_page.dart';
import '../contacts/link_conversation_page.dart';
import '../../shared/contact_store.dart';
import '../../shared/conversation_store.dart';
import '../../shared/message_source.dart';

class ChatPage extends StatefulWidget {
  /// Если чат открыт из входящих, мы знаем conversationId.
  /// Он нужен для ручной привязки/перепривязки.
  final String? conversationId;
  final String contactId;
  final MessageSource channelSource;
  final String channelHandle;

  const ChatPage({
    super.key,
    this.conversationId,
    required this.contactId,
    required this.channelSource,
    required this.channelHandle,
  });

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  // Пока это заглушка: простые сообщения, чтобы можно было long-tap и создать заметку.
  final List<_Msg> _messages = <_Msg>[
    _Msg(fromMe: false, text: 'Привет! Можно узнать про доставку?'),
    _Msg(fromMe: true, text: 'Да, конечно. Куда нужно доставить?'),
    _Msg(fromMe: false, text: 'В пятёрочку у дома. И ещё вопрос по оплате.'),
    _Msg(fromMe: true, text: 'Ок, сейчас уточню и напишу.'),
  ];

  @override
  Widget build(BuildContext context) {
    final contact = ContactStore.instance.tryGet(widget.contactId);
    final name = contact?.displayName ?? 'Контакт';

    return Scaffold(
      appBar: AppBar(
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'open_contact') {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => ContactPage(contactId: widget.contactId)),
                );
              }
              if (v == 'link' && widget.conversationId != null) {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => LinkConversationPage(conversationId: widget.conversationId!)),
                );
              }
              if (v == 'new_contact' && widget.conversationId != null) {
                final c = ConversationStore.instance.createNewContactAndLink(widget.conversationId!);
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Создан новый контакт и привязан диалог')),
                );
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => ContactPage(contactId: c.id)),
                );
              }
            },
            itemBuilder: (ctx) {
              final items = <PopupMenuEntry<String>>[
                const PopupMenuItem(value: 'open_contact', child: Text('Открыть контакт')),
              ];
              if (widget.conversationId != null) {
                items.add(const PopupMenuDivider());
                items.add(const PopupMenuItem(value: 'link', child: Text('Привязать к контакту…')));
                items.add(const PopupMenuItem(value: 'new_contact', child: Text('Создать новый контакт')));
              }
              return items;
            },
          ),
        ],
        title: GestureDetector(
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => ContactPage(contactId: widget.contactId),
              ),
            );
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
              Text(
                '${widget.channelSource.label} • ${widget.channelHandle}',
                style: const TextStyle(fontSize: 12),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        itemCount: _messages.length,
        itemBuilder: (_, i) {
          final m = _messages[i];
          return _MessageBubble(
            msg: m,
            onLongPress: () => _openMessageActions(m),
          );
        },
      ),
    );
  }

  Future<void> _openMessageActions(_Msg msg) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (ctx) {
        final maxH = MediaQuery.of(ctx).size.height * 0.9;
        final bottomPad = MediaQuery.of(ctx).padding.bottom + 10 + MediaQuery.of(ctx).viewInsets.bottom;
        return SafeArea(
          top: false,
          bottom: false,
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: maxH),
            child: ListView(
              shrinkWrap: true,
              padding: EdgeInsets.only(bottom: bottomPad),
              children: [
                ListTile(
                  leading: const Icon(Icons.note_add_outlined),
                  title: const Text('Создать заметку из сообщения'),
                  onTap: () {
                    Navigator.of(ctx).pop();
                    // Создаём заметку сразу (без сложной логики). Это уже полезно.
                    ContactStore.instance.addNote(widget.contactId, msg.text);
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Заметка добавлена в карточку контакта')),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.copy_all_outlined),
                  title: const Text('Скопировать текст'),
                  onTap: () {
                    Navigator.of(ctx).pop();
                    Clipboard.setData(ClipboardData(text: msg.text));
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Скопировано')),
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _Msg {
  final bool fromMe;
  final String text;
  const _Msg({required this.fromMe, required this.text});
}

class _MessageBubble extends StatelessWidget {
  final _Msg msg;
  final VoidCallback onLongPress;

  const _MessageBubble({required this.msg, required this.onLongPress});

  @override
  Widget build(BuildContext context) {
    final align = msg.fromMe ? Alignment.centerRight : Alignment.centerLeft;
    final bg = msg.fromMe ? Colors.green.withOpacity(0.15) : Colors.black.withOpacity(0.06);

    return Align(
      alignment: align,
      child: InkWell(
        onLongPress: onLongPress,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          constraints: const BoxConstraints(maxWidth: 320),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.black.withOpacity(0.06)),
          ),
          child: Text(msg.text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
        ),
      ),
    );
  }
}
