import 'package:flutter/material.dart';
import '../../shared/task_models.dart';

class TasksPage extends StatefulWidget {
  const TasksPage({super.key});

  @override
  State<TasksPage> createState() => _TasksPageState();
}

class _TasksPageState extends State<TasksPage> {
  final TextEditingController _input = TextEditingController();
  final ScrollController _scroll = ScrollController();

  final List<String> _folders = ['Входящие', 'Покупки', 'Доставка', 'Архив'];

  // null => показываем ВСЕ задачи (по умолчанию)
  String? _selectedFolder;

  final List<TaskItem> _tasks = [
    TaskItem(
      id: '1',
      text: 'Отправить трек клиенту (Яндекс)',
      createdAt: DateTime.now().subtract(const Duration(minutes: 10)),
      status: TaskStatus.done,
      isStriked: false,
      folder: 'Доставка',
    ),
    TaskItem(
      id: '2',
      text: 'Купить упаковку и скотч',
      createdAt: DateTime.now().subtract(const Duration(minutes: 22)),
      status: TaskStatus.doing,
      isStriked: false,
      folder: 'Покупки',
    ),
    TaskItem(
      id: '3',
      text: 'Позвонить клиенту по заказу #123',
      createdAt: DateTime.now().subtract(const Duration(minutes: 35)),
      status: TaskStatus.todo,
      isStriked: false,
      folder: 'Входящие',
    ),
  ];

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final visible = _tasks.where((t) {
      if (_selectedFolder == null) return true;
      return t.folder == _selectedFolder;
    }).toList()
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Задачи'),
        actions: [
          IconButton(
            tooltip: 'Добавить папку',
            icon: const Icon(Icons.add),
            onPressed: _createFolder,
          ),
        ],
      ),
      body: Column(
        children: [
          _FolderTabsBar(
            folders: _folders,
            selected: _selectedFolder,
            onTap: (folder) {
              setState(() {
                if (_selectedFolder == folder) {
                  _selectedFolder = null; // снять фильтр => все задачи
                } else {
                  _selectedFolder = folder;
                }
              });
            },
            onLongPress: _openFolderMenu,
          ),
          const Divider(height: 1),

          Expanded(
            child: ListView.builder(
              controller: _scroll,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              itemCount: visible.length,
              itemBuilder: (context, index) {
                final task = visible[index];
                return _TaskBubble(
                  task: task,
                  onTap: () => setState(() => task.status = task.status.next()),
                  onLongPress: () => _openTaskMenu(task),
                );
              },
            ),
          ),

          const Divider(height: 1),

          _InputBar(
            controller: _input,
            onSend: _addTaskFromInput,
            onAttach: _attachStub,
          ),
        ],
      ),
    );
  }

  void _addTaskFromInput() {
    final text = _input.text.trim();
    if (text.isEmpty) return;

    final folder = _selectedFolder ?? 'Входящие';

    final task = TaskItem(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      text: text,
      createdAt: DateTime.now(),
      status: TaskStatus.todo,
      isStriked: false,
      folder: folder,
    );

    setState(() {
      _tasks.add(task);
      _input.clear();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      _scroll.animateTo(
        _scroll.position.maxScrollExtent + 300,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  void _attachStub() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Вложения добавим следующим шагом')),
    );
  }

  Future<void> _createFolder() async {
    final name = await _promptText(
      title: 'Новая папка',
      hint: 'Название папки',
      initial: 'Новая папка',
    );
    if (name == null) return;

    final trimmed = name.trim();
    if (trimmed.isEmpty) return;

    setState(() {
      if (!_folders.contains(trimmed)) {
        _folders.insert(_folders.length - 1, trimmed); // перед Архивом
      }
      _selectedFolder = trimmed;
    });
  }

  void _openFolderMenu(String folder) {
    final isArchive = folder == 'Архив';

    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(title: Text(folder), subtitle: const Text('Папка задач')),
            const Divider(height: 1),

            if (!isArchive)
              ListTile(
                leading: const Icon(Icons.edit),
                title: const Text('Переименовать'),
                onTap: () async {
                  Navigator.pop(context);
                  final newName = await _promptText(
                    title: 'Переименовать папку',
                    hint: 'Название',
                    initial: folder,
                  );
                  if (newName == null) return;
                  final t = newName.trim();
                  if (t.isEmpty) return;

                  setState(() {
                    final idx = _folders.indexOf(folder);
                    if (idx != -1) _folders[idx] = t;

                    for (final task in _tasks) {
                      if (task.folder == folder) task.folder = t;
                    }

                    if (_selectedFolder == folder) _selectedFolder = t;
                  });
                },
              ),

            if (!isArchive)
              ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('Удалить папку'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _folders.remove(folder);
                    if (_selectedFolder == folder) _selectedFolder = null;
                  });
                },
              ),

            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  void _openTaskMenu(TaskItem task) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('Действия'),
              subtitle: Text(task.text, maxLines: 2, overflow: TextOverflow.ellipsis),
            ),
            const Divider(height: 1),

            ListTile(
              leading: const Icon(Icons.drive_file_move_outline),
              title: const Text('Переместить в папку…'),
              onTap: () async {
                Navigator.pop(context);
                final picked = await _pickFolderFullScreen(current: task.folder);
                if (picked == null) return;
                setState(() => task.folder = picked);
              },
            ),

            ListTile(
              leading: const Icon(Icons.format_strikethrough),
              title: Text(task.isStriked ? 'Снять зачёркивание' : 'Зачеркнуть'),
              onTap: () {
                setState(() => task.isStriked = !task.isStriked);
                Navigator.pop(context);
              },
            ),

            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text('Удалить'),
              onTap: () {
                setState(() => _tasks.removeWhere((t) => t.id == task.id));
                Navigator.pop(context);
              },
            ),

            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Future<String?> _pickFolderFullScreen({required String current}) async {
    return Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (_) => _FolderPickPage(
          folders: _folders,
          current: current,
          onCreateFolder: _createFolderFromPicker,
        ),
      ),
    );
  }

  Future<String?> _createFolderFromPicker() async {
    final name = await _promptText(
      title: 'Новая папка',
      hint: 'Название папки',
      initial: 'Новая папка',
    );
    if (name == null) return null;

    final trimmed = name.trim();
    if (trimmed.isEmpty) return null;

    setState(() {
      if (!_folders.contains(trimmed)) {
        _folders.insert(_folders.length - 1, trimmed);
      }
    });

    return trimmed;
  }

  Future<String?> _promptText({
    required String title,
    required String hint,
    required String initial,
  }) async {
    final ctrl = TextEditingController(text: initial);

    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: ctrl,
          decoration: InputDecoration(hintText: hint),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('Ок')),
        ],
      ),
    );
  }
}

class _FolderTabsBar extends StatelessWidget {
  final List<String> folders;
  final String? selected;
  final ValueChanged<String> onTap;
  final ValueChanged<String> onLongPress;

  const _FolderTabsBar({
    required this.folders,
    required this.selected,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    // Табы компактнее и на всю ширину. Wrap сам сделает второй ряд.
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
      child: LayoutBuilder(
        builder: (context, constraints) {
          return Wrap(
            spacing: 8,
            runSpacing: 8,
            children: folders.map((folder) {
              final isSelected = selected == folder;

              return GestureDetector(
                onTap: () => onTap(folder),
                onLongPress: () => onLongPress(folder),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  decoration: BoxDecoration(
                    color: isSelected ? Colors.black.withOpacity(0.06) : Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.black12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.25),
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        folder,
                        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}

class _FolderPickPage extends StatelessWidget {
  final List<String> folders;
  final String current;
  final Future<String?> Function() onCreateFolder;

  const _FolderPickPage({
    required this.folders,
    required this.current,
    required this.onCreateFolder,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Выберите папку')),
      body: ListView(
        children: [
          ListTile(
            leading: const CircleAvatar(
              backgroundColor: Colors.black12,
              child: Icon(Icons.add, color: Colors.black87),
            ),
            title: const Text('Новая папка'),
            onTap: () async {
              final created = await onCreateFolder();
              if (created == null) return;
              Navigator.pop(context, created);
            },
          ),
          const Divider(height: 1),
          ...folders.map((f) {
            final selected = f == current;
            return ListTile(
              leading: Icon(
                selected ? Icons.check_circle : Icons.circle_outlined,
                color: selected ? Colors.black87 : Colors.black26,
              ),
              title: Text(f),
              onTap: () => Navigator.pop(context, f),
            );
          }),
        ],
      ),
    );
  }
}

class _TaskBubble extends StatelessWidget {
  final TaskItem task;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  const _TaskBubble({
    required this.task,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final time = _formatTime(task.createdAt);

    // Цвета как на твоём хорошем скрине (мягкие)
    final bubble = _bubbleColor(task.status);

    final textStyle = TextStyle(
      color: Colors.black87,
      fontSize: 15,
      fontWeight: FontWeight.w800,
      decoration: task.isStriked ? TextDecoration.lineThrough : TextDecoration.none,
      decorationThickness: 2,
    );

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Align(
        alignment: Alignment.centerLeft,
        child: GestureDetector(
          onTap: onTap,
          onLongPress: onLongPress,
          child: Container(
            constraints: const BoxConstraints(maxWidth: 360),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: bubble,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.black.withOpacity(0.06)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(task.text, style: textStyle),
                const SizedBox(height: 6),
                Text(
                  time,
                  style: TextStyle(
                    color: Colors.black.withOpacity(0.55),
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Color _bubbleColor(TaskStatus s) {
    switch (s) {
      case TaskStatus.todo:
        return const Color(0xFFF8D7DA); // мягкий розовый
      case TaskStatus.doing:
        return const Color(0xFFFFF3CD); // мягкий жёлтый
      case TaskStatus.done:
        return const Color(0xFFD1E7DD); // мягкий зелёный
    }
  }

  String _formatTime(DateTime dt) {
    String two(int v) => v.toString().padLeft(2, '0');
    return '${two(dt.hour)}:${two(dt.minute)}';
  }
}

class _InputBar extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSend;
  final VoidCallback onAttach;

  const _InputBar({
    required this.controller,
    required this.onSend,
    required this.onAttach,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
        child: Row(
          children: [
            IconButton(onPressed: onAttach, icon: const Icon(Icons.attach_file)),
            Expanded(
              child: TextField(
                controller: controller,
                minLines: 1,
                maxLines: 4,
                decoration: InputDecoration(
                  hintText: 'Написать задачу…',
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(18),
                    borderSide: const BorderSide(color: Colors.black12),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(18),
                    borderSide: const BorderSide(color: Colors.black12),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(18),
                    borderSide: const BorderSide(color: Colors.black12),
                  ),
                ),
                onSubmitted: (_) => onSend(),
              ),
            ),
            const SizedBox(width: 8),
            IconButton(onPressed: onSend, icon: const Icon(Icons.send)),
          ],
        ),
      ),
    );
  }
}
