import 'package:flutter/material.dart';

class StructurePage extends StatelessWidget {
  const StructurePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text(
          'Структура',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
