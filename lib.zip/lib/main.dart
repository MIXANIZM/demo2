import 'package:flutter/material.dart';
import 'navigation/home_page.dart';

final GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

void main() {
  runApp(const MessengerCrmApp());
}

class MessengerCrmApp extends StatelessWidget {
  const MessengerCrmApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: appNavigatorKey,
      debugShowCheckedModeBanner: false,
      title: 'Messenger CRM',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        scaffoldBackgroundColor: const Color(0xFFF5F5F5),
      ),

      // Чтобы клики мимо инпутов гарантированно снимали фокус (и клавиатуру)
      builder: (context, child) {
        return GestureDetector(
          onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
          behavior: HitTestBehavior.translucent,
          child: child ?? const SizedBox.shrink(),
        );
      },

      home: const HomePage(),
    );
  }
}
